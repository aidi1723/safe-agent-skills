from __future__ import annotations

from dataclasses import replace
import json
from pathlib import Path
import re
from typing import Any

from . import __version__
from .compatibility import build_canonical_content_hash
from .compatibility import build_route_id
from .compatibility import build_route_identity_payload
from .compatibility import redact_route_identity_text
from .compatibility import v3_compatibility_report
from .intent import decompose_task, normalize_task
from .need_gate import (
    CAPABILITY_PATTERNS,
    CAPABILITY_SKILL,
    SKILL_NAME_PATTERNS,
    decide_skill_need,
    mask_canonical_skill_names,
    mask_unauthorized_canonical_skill_occurrences,
    positive_explicit_skill_occurrences,
)
from .registry import load_registry_index, utc_now, verify_registry
from .scenario_matcher import match_scenario_bundle
from .scenario_matcher_v2 import match_scenario_bundle_v2
from .semantic_provider import SemanticProvider, rerank_candidates
from .skill_candidates import HIGH_FREQUENCY_ENTRY_NAMES
from .skill_candidates import load_cohort_profiles
from .skill_candidates import load_routing_examples
from .skill_candidates import retrieve_skill_candidates
from .skill_selection import compose_skill_selection
from .task_packs import load_skill_pack_item


_STRONG_ORDER_BOUNDARY_RE = re.compile(r"[.;\n。；！？!?]+")
_BINARY_ORDER_CONNECTOR_RE = re.compile(
    r"(?P<after>\bafter\b)|(?P<before>\bbefore\b)|"
    r"(?P<after_zh>之后)|(?P<before_zh>之前)",
    re.IGNORECASE,
)
_SEQUENCE_ORDER_CONNECTOR_RE = re.compile(r"\bthen\b|然后|再|最后", re.IGNORECASE)
_GROUP_CONTINUATION_RE = re.compile(
    r"(?:\b(?:but|and)\b|但是|但|并且|且)\s*[,，]?\s*$", re.IGNORECASE
)
_ELIDED_GROUP_CONTINUATION_RE = re.compile(r"\s*[,，]\s*$")
_LOCAL_ORDER_BOUNDARY_RE = re.compile(
    r"(?P<comma>[,，])|(?P<but>\bbut\b)|(?P<and>\band\b)|"
    r"(?P<coordination_zh>但是|但|并且|且)",
    re.IGNORECASE,
)
_COMPOUND_GERUND_RE = re.compile(
    r"\b[a-z]+ing\s+and\s+(?:(?:then|[a-z]+ly)\s+)?[a-z]+ing\b",
    re.IGNORECASE,
)
_XIAN_SCOPE_BOUNDARY_RE = re.compile(
    r"\b(?:but|independently|separately)\b|但是|但|同时", re.IGNORECASE
)
_XIAN_RE = re.compile(r"先(?!不)")


def build_task_pack_v3(
    registry_dir: Path,
    task: str,
    bundles_path: Path,
    routing_examples_path: Path,
    *,
    max_candidates: int = 3,
    semantic_provider: SemanticProvider | None = None,
    semantic_mode: str = "shadow",
    use_bundle_v2: bool = False,
) -> dict[str, Any]:
    if not task.strip():
        raise ValueError("task must not be empty")
    if semantic_mode not in {"none", "shadow", "influence"}:
        raise ValueError("semantic_mode must be none, shadow, or influence")

    verification = verify_registry(registry_dir)
    if verification["status"] != "ok":
        raise SystemExit("registry verification failed; refusing to build task pack")

    normalized = normalize_task(task)
    routing_current = redact_route_identity_text(normalized.current)
    routing_normalized = replace(normalized, current=routing_current)
    intent_graph = decompose_task(routing_current)
    need = decide_skill_need(routing_normalized)
    examples = load_routing_examples(routing_examples_path)
    profiles = load_cohort_profiles(registry_dir)
    candidates = retrieve_skill_candidates(
        routing_normalized,
        need,
        profiles,
        examples,
        top_k=max_candidates,
    )
    active_provider = None if need["decision"] == "none" else semantic_provider
    candidates, provider_record = rerank_candidates(
        routing_current,
        need,
        candidates,
        active_provider,
        mode="none" if active_provider is None else semantic_mode,
    )
    explicit_order = _extract_explicit_skill_order(routing_current, need, candidates)
    composed = compose_skill_selection(
        need,
        candidates,
        profiles,
        explicit_order=explicit_order,
    )

    # Phase 4.1 (2026-09-13): Bundle v2 with conditional skill selection
    # For specialized tasks, use Bundle v2 (core + conditional) or fallback to Phase 3.1
    selected_scenario = None
    if need["specialized_need"]:
        if use_bundle_v2:
            # Bundle v2: core + conditional skills based on task keywords
            matched = match_scenario_bundle_v2(routing_current, bundles_path, threshold=0.12)
            if matched:
                selected_scenario = matched["id"]
                composed = dict(composed)
                composed["selected_skill_names"] = matched["skills"]
                composed["selection_method"] = "scenario_bundle_v2_conditional"
                composed["scenario_match"] = {
                    "id": matched["id"],
                    "name": matched["name"],
                    "score": matched["match_score"],
                    "confidence": matched["match_confidence"],
                    "core_count": matched["skill_selection"]["core_count"],
                    "conditional_matched": matched["skill_selection"]["conditional_matched"],
                    "conditional_skipped": matched["skill_selection"]["conditional_skipped"],
                }
        else:
            # Phase 3.1: Intersection filtering (fallback)
            matched = match_scenario_bundle(routing_current, bundles_path, threshold=0.12)
            if matched:
                selected_scenario = matched["id"]
                # Get intersection of cohort top-7 candidates and scenario skills
                cohort_top7_skills = {c["skill"] for c in candidates[:7]}
                scenario_skills = set(matched["skills"])
                intersection_skills = list(cohort_top7_skills & scenario_skills)

                composed = dict(composed)
                if intersection_skills:
                    # Use intersection skills
                    composed["selected_skill_names"] = intersection_skills
                    composed["selection_method"] = "scenario_cohort_intersection"
                else:
                    # Fallback: no intersection, keep cohort selection
                    composed["selection_method"] = "cohort_only_no_intersection"

                composed["scenario_match"] = {
                    "id": matched["id"],
                    "name": matched["name"],
                    "score": matched["match_score"],
                    "confidence": matched["match_confidence"],
                    "cohort_count": len(cohort_top7_skills),
                    "scenario_count": len(scenario_skills),
                "intersection_count": len(intersection_skills),
            }

    registry_index = load_registry_index(registry_dir)
    entries = {entry["name"]: entry for entry in registry_index["skills"]}
    selected_items = [
        load_skill_pack_item(registry_dir, entries[name])
        for name in composed["selected_skill_names"]
    ]
    selected_names = set(composed["selected_skill_names"])
    traced_candidates = [
        _trace_candidate(candidate, selected_names)
        for candidate in candidates
    ]

    bundles = json.loads(bundles_path.read_text(encoding="utf-8"))
    examples_content_hash = build_canonical_content_hash(examples)
    route_identity = {
        "base": build_route_identity_payload(
            current=normalized.current,
            history=normalized.history,
            stale=normalized.stale,
            stale_policy=normalized.stale_policy,
            invariants=[],
            capabilities=need["required_capabilities"],
            strategy="high_frequency_v3",
            provider_identifier=provider_record["used"],
            catalog_content_hash=build_canonical_content_hash(registry_index),
            bundle_content_hash=build_canonical_content_hash(bundles),
            overlap_content_hash="none",
            router_version="high-frequency-intelligent-router-v3",
            package_version=__version__,
        ),
        "routing_examples_content_hash": examples_content_hash,
        "cohort_names": list(HIGH_FREQUENCY_ENTRY_NAMES),
        "routing_configuration": {
            "max_candidates": max_candidates,
            "semantic_mode": semantic_mode,
            "provider": {
                "requested": provider_record["requested"],
                "used": provider_record["used"],
                "model_or_adapter": provider_record["model_or_adapter"],
                "candidate_scope_hash": provider_record["candidate_scope_hash"],
            },
        },
        "constraints": {
            "excluded_skills": need["excluded_skills"],
            "missing_inputs": need["missing_inputs"],
            "mandatory_capabilities": need["mandatory_capabilities"],
        },
    }
    payload = {
        "schema_version": 3,
        "generated_at": utc_now(),
        "route_id": build_route_id(route_identity),
        "routing_mode": (
            "deterministic"
            if provider_record["used"] == "none"
            else "semantic_shadow"
            if semantic_mode == "shadow"
            else "hybrid"
        ),
        "routing_status": composed["routing_status"],
        "provider": provider_record,
        "normalized_task": normalized.to_json(),
        "need_decision": need,
        "intent_graph": intent_graph.to_json(),
        "candidates": traced_candidates,
        "selection": {
            **composed["selection"],
            "need_decision": need["decision"],
            "selected_skills": selected_items,
            "selected_scenario": selected_scenario,
        },
        "capability_resolution": composed["capability_resolution"],
        "execution_graph": composed["execution_graph"],
        "confidence": composed["confidence"],
        "host_execution_protocol": {
            "mode": "method_only",
            "runtime_boundary": "The host runtime controls permissions and execution.",
            "node_statuses": [
                "pending",
                "ready",
                "running",
                "waiting_approval",
                "completed",
                "failed",
                "blocked",
                "skipped",
            ],
        },
        "routing_metrics": {
            "candidate_count": len(traced_candidates),
            "selected_skill_count": len(selected_items),
            "required_capability_count": len(need["required_capabilities"]),
            "covered_capability_count": composed["capability_resolution"]["covered_count"],
            "runtime_example_count": len(examples),
            "cohort_candidate_count": len(profiles),
        },
        "registry_verification": {
            "catalog": verification,
            "routing_examples": {
                "status": "ok",
                "count": len(examples),
                "content_hash": examples_content_hash,
            },
        },
        "compatibility": {},
    }
    payload["compatibility"] = v3_compatibility_report(payload)
    return payload


def _trace_candidate(candidate: dict[str, Any], selected_names: set[str]) -> dict[str, Any]:
    traced = json.loads(json.dumps(candidate, ensure_ascii=False))
    selected = traced["skill"] in selected_names
    traced["selected"] = selected
    traced["reason_codes"] = sorted(
        set(traced["reason_codes"]) | ({"selected"} if selected else {"rejected"})
    )
    return traced


def _extract_explicit_skill_order(
    current: str,
    need: dict[str, Any],
    candidates: list[dict[str, Any]],
) -> list[tuple[str, str]]:
    admitted = {item["skill"] for item in candidates}
    required = set(need["required_capabilities"])
    relations: list[tuple[str, str]] = []
    for clause in _STRONG_ORDER_BOUNDARY_RE.split(current):
        if not clause.strip():
            continue
        positive_occurrences = positive_explicit_skill_occurrences(clause)
        order_clause = mask_unauthorized_canonical_skill_occurrences(
            clause, positive_occurrences
        )
        explicit = {name for name, _, _ in positive_occurrences}
        relations.extend(
            _binary_order_relations(order_clause, required, admitted, explicit)
        )
        relations.extend(
            _sequence_order_relations(order_clause, required, admitted, explicit)
        )

    return list(dict.fromkeys(relation for relation in relations if relation[0] != relation[1]))


def _binary_order_relations(
    clause: str,
    required: set[str],
    admitted: set[str],
    explicit: set[str],
) -> list[tuple[str, str]]:
    connectors = list(_BINARY_ORDER_CONNECTOR_RE.finditer(clause))
    if not connectors:
        return []

    active_anchor = _last_skill(
        clause[: connectors[0].start()], required, admitted, explicit
    )
    relations: list[tuple[str, str]] = []
    for index, connector in enumerate(connectors):
        separator = re.match(r"\s*[,，]?\s*", clause[connector.end() :])
        complement_start = connector.end() + (separator.end() if separator else 0)
        complement_end = _next_local_complement_boundary_start(clause, complement_start)
        complement = _first_skill(
            clause[complement_start:complement_end], required, admitted, explicit
        )
        if index:
            previous = connectors[index - 1]
            gap = clause[previous.end() : connector.start()]
            gap_mentions = _skill_mentions(gap, required, admitted, explicit)
            gap_actions = _unique_skill_mentions(gap_mentions)
            continues_group = bool(_GROUP_CONTINUATION_RE.search(gap)) and len(gap_actions) <= 1
            if not continues_group and gap_mentions and len(gap_actions) <= 1:
                complement_suffix = gap[gap_mentions[-1][1] :]
                continues_group = bool(
                    _ELIDED_GROUP_CONTINUATION_RE.fullmatch(complement_suffix)
                )
            if not continues_group:
                active_anchor = gap_mentions[-1][2] if gap_mentions else _last_skill(
                    clause[: connector.start()], required, admitted, explicit
                )
        if active_anchor is None or complement is None:
            continue
        relations.append(_direct_binary_relation(connector.lastgroup, active_anchor, complement))
    return relations


def _direct_binary_relation(kind: str | None, anchor: str, complement: str) -> tuple[str, str]:
    if kind == "after":
        return complement, anchor
    if kind == "before":
        return anchor, complement
    # Chinese temporal connectors are postfixes attached to the anchor action.
    if kind == "after_zh":
        return anchor, complement
    return complement, anchor


def _sequence_order_relations(
    clause: str,
    required: set[str],
    admitted: set[str],
    explicit: set[str],
) -> list[tuple[str, str]]:
    relations: list[tuple[str, str]] = []
    for connector in _SEQUENCE_ORDER_CONNECTOR_RE.finditer(clause):
        if _is_internal_compound_gerund_marker(clause, connector):
            continue
        separator = re.match(r"\s*[,，]?\s*", clause[connector.end() :])
        complement_start = connector.end() + (separator.end() if separator else 0)
        complement_end = _next_local_complement_boundary_start(clause, complement_start)
        left = _last_skill(
            clause[: connector.start()], required, admitted, explicit
        )
        right = _first_skill(
            clause[complement_start:complement_end], required, admitted, explicit
        )
        if left is not None and right is not None:
            relations.append((left, right))

    xian = _XIAN_RE.search(clause)
    if xian is not None:
        binary_boundary = _next_order_boundary_start(
            clause, xian.end(), (_BINARY_ORDER_CONNECTOR_RE,)
        )
        sequence_boundary = _next_sequence_order_boundary_start(clause, xian.end())
        adversative_boundary = _next_order_boundary_start(
            clause, xian.end(), (_XIAN_SCOPE_BOUNDARY_RE,)
        )
        scope_end = min(binary_boundary, sequence_boundary, adversative_boundary)
        ordered = [
            item[2]
            for item in _skill_mentions(
                clause[xian.end() : scope_end], required, admitted, explicit
            )
        ]
        relations.extend(zip(ordered, ordered[1:]))
    return relations


def _next_order_boundary_start(
    text: str,
    start: int,
    patterns: tuple[re.Pattern[str], ...],
) -> int:
    matches = [match.start() for pattern in patterns if (match := pattern.search(text, start))]
    return min(matches, default=len(text))


def _next_sequence_order_boundary_start(text: str, start: int) -> int:
    return next(
        (
            match.start()
            for match in _SEQUENCE_ORDER_CONNECTOR_RE.finditer(text, start)
            if not _is_internal_compound_gerund_marker(text, match)
        ),
        len(text),
    )


def _next_local_complement_boundary_start(text: str, start: int) -> int:
    binary_boundary = _next_order_boundary_start(
        text, start, (_BINARY_ORDER_CONNECTOR_RE,)
    )
    sequence_boundary = _next_sequence_order_boundary_start(text, start)
    local_boundary = next(
        (
            match.start()
            for match in _LOCAL_ORDER_BOUNDARY_RE.finditer(text, start)
            if not _is_internal_gerund_conjunction(text, match)
        ),
        len(text),
    )
    return min(binary_boundary, sequence_boundary, local_boundary)


def _is_internal_gerund_conjunction(text: str, match: re.Match[str]) -> bool:
    return match.lastgroup == "and" and _is_internal_compound_gerund_marker(text, match)


def _is_internal_compound_gerund_marker(text: str, match: re.Match[str]) -> bool:
    return any(
        compound.start() < match.start() and match.end() < compound.end()
        for compound in _COMPOUND_GERUND_RE.finditer(text)
    )


def _first_skill(
    text: str,
    required: set[str],
    admitted: set[str],
    explicit: set[str],
) -> str | None:
    mentions = _skill_mentions(text, required, admitted, explicit)
    return mentions[0][2] if mentions else None


def _last_skill(
    text: str,
    required: set[str],
    admitted: set[str],
    explicit: set[str],
) -> str | None:
    mentions = _skill_mentions(text, required, admitted, explicit)
    return mentions[-1][2] if mentions else None


def _skill_mentions(
    text: str,
    required: set[str],
    admitted: set[str],
    explicit: set[str],
) -> list[tuple[int, int, str]]:
    mentions: list[tuple[int, int, str]] = []
    masked_text = mask_canonical_skill_names(text)
    for capability, pattern in CAPABILITY_PATTERNS.items():
        skill = CAPABILITY_SKILL[capability]
        if capability in required and skill in admitted:
            mentions.extend(
                (match.start(), match.end(), skill)
                for match in pattern.finditer(masked_text)
            )
        if capability in required and skill in admitted and skill in explicit:
            name_pattern = SKILL_NAME_PATTERNS[skill]
            mentions.extend(
                (match.start(), match.end(), skill)
                for match in name_pattern.finditer(text)
            )
    return sorted(mentions, key=lambda item: (item[0], item[1], item[2]))


def _unique_skill_mentions(
    mentions: list[tuple[int, int, str]],
) -> list[tuple[int, int, str]]:
    unique: list[tuple[int, int, str]] = []
    seen: set[str] = set()
    for mention in mentions:
        if mention[2] not in seen:
            unique.append(mention)
            seen.add(mention[2])
    return unique
